# TravelGuard — Android MVP refresh

TravelGuard helps a passenger avoid missing a destination and notice unexpected route deviations.

## What's included in this refresh

- Refreshed native Android interface with a Google-inspired visual language (not affiliated with Google).
- Destination search using Android Geocoder.
- Interactive OpenStreetMap view embedded in the app using Leaflet.
- Destination radar with a live-adjusting radius slider from 100 m to 10 km.
- Route-deviation threshold slider from 100 m to 1 km.
- Foreground location-monitoring service.
- Destination and route-deviation notifications with repeating alarm/vibration until the user taps **I'm awake**.
- No API keys, paid APIs, ads, analytics SDKs, or in-app purchases.

## Build

1. Extract this ZIP.
2. Open the `TravelGuard` folder in Android Studio.
3. Allow Gradle to sync. The build downloads the Android Gradle Plugin, Kotlin plugin, AndroidX Core and Google Play Services Location.
4. Build the debug APK using **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The project requires Java 17 and Android SDK 35. Minimum Android version is Android 8.0 (API 26).

## First run

- Grant precise location permission.
- Grant notification permission when prompted.
- Start monitoring while the app is visible.
- Keep the foreground-service notification enabled.
- If your phone manufacturer aggressively restricts background activity, allow TravelGuard to run without battery optimization.

## Important limitations

- This is source code, not a prebuilt APK. It has not been compiled or validated on a physical phone in this environment.
- Destination search uses Android's Geocoder implementation; place results depend on Android/device geocoding availability.
- The map uses Leaflet from a public CDN and OpenStreetMap's public tile service. These are community/public services with usage policies and no uptime guarantee. The map needs internet.
- Route Guard requests a driving route from the public OSRM demo endpoint. The endpoint has fair-use limits and no SLA; it is not suitable as a guaranteed production backend.
- GPS proximity monitoring itself does not require the map or routing service once the destination coordinates have been resolved.
- The route is calculated once at journey start. A legitimate diversion can trigger an alert. The current MVP does not automatically reroute or distinguish a bus stop from a road diversion.
- GPS accuracy, tunnels, device battery management, Android notification settings, silent mode and Do Not Disturb can affect alert timing or sound.
- The app cannot guarantee an alarm will override Android or manufacturer restrictions. Test it on your actual device before relying on it for an important journey.
- The map currently focuses on the selected destination and its geofence. It is not a full turn-by-turn navigation screen.

## Privacy and cost

- No Google Maps API key or paid map API is used.
- No advertising or analytics SDK is included.
- Destination coordinates are sent to the public OSRM demo service when route calculation is requested. Map tiles are fetched from OpenStreetMap tile servers. Geocoding is provided by the Android device's Geocoder.
- Review the terms and usage policies of public community endpoints before wider/public deployment.
