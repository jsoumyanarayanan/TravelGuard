package com.travelguard.app

import android.app.*
import android.content.Intent
import android.location.Location
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.media.Ringtone
import android.app.PendingIntent
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import kotlin.math.*

class TravelMonitorService : Service() {
    companion object { private const val ACTION_ACKNOWLEDGE = "com.travelguard.app.ACKNOWLEDGE_ALERT" }
    private lateinit var fused: FusedLocationProviderClient
    private var destinationName = "destination"
    private var destLat = 0.0
    private var destLon = 0.0
    private var radiusM = 1000.0
    private var deviationM = 250.0
    private var route: List<Pair<Double, Double>> = emptyList()
    private var destinationAlerted = false
    private var deviationCount = 0
    private var lastDeviationAlert = 0L
    private var callback: LocationCallback? = null
    private var activeRingtone: Ringtone? = null
    private var activeVibrator: Vibrator? = null

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
        createChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_ACKNOWLEDGE) {
            stopAlert()
            return START_NOT_STICKY
        }
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        destinationName = intent.getStringExtra("dest_name") ?: "destination"
        destLat = intent.getDoubleExtra("dest_lat", 0.0)
        destLon = intent.getDoubleExtra("dest_lon", 0.0)
        radiusM = intent.getDoubleExtra("radius_m", 1000.0)
        deviationM = intent.getDoubleExtra("deviation_m", 250.0)
        destinationAlerted = false
        deviationCount = 0
        startForeground(1, buildNotification("Monitoring journey to $destinationName"))
        loadRouteAndStartUpdates()
        return START_STICKY
    }

    private fun loadRouteAndStartUpdates() {
        thread {
            try {
                val last = fused.lastLocation
                val start = try { com.google.android.gms.tasks.Tasks.await(last) } catch (_: Exception) { null }
                if (start != null) route = fetchRoute(start.latitude, start.longitude, destLat, destLon)
            } catch (_: Exception) { }
            startLocationUpdates()
        }
    }

    private fun fetchRoute(aLat: Double, aLon: Double, bLat: Double, bLon: Double): List<Pair<Double, Double>> {
        val url = URL("https://router.project-osrm.org/route/v1/driving/$aLon,$aLat;$bLon,$bLat?overview=full&geometries=geojson")
        val conn = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 10000; requestMethod = "GET" }
        return try {
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val coords = json.getJSONArray("routes").getJSONObject(0).getJSONObject("geometry").getJSONArray("coordinates")
            (0 until coords.length()).map { i -> val p = coords.getJSONArray(i); Pair(p.getDouble(1), p.getDouble(0)) }
        } finally { conn.disconnect() }
    }

    @Suppress("MissingPermission")
    private fun startLocationUpdates() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L).setMinUpdateDistanceMeters(10f).build()
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val distance = distanceMeters(loc.latitude, loc.longitude, destLat, destLon)
                if (!destinationAlerted && distance <= radiusM) {
                    destinationAlerted = true
                    alert("Destination nearby", "$destinationName is approximately ${formatDistance(distance)} away. Get ready to get off.", 2)
                }
                if (route.isNotEmpty()) {
                    val offRoute = distanceToRoute(loc.latitude, loc.longitude, route)
                    if (offRoute > deviationM) deviationCount++ else deviationCount = 0
                    val now = System.currentTimeMillis()
                    if (deviationCount >= 3 && now - lastDeviationAlert > 120000) {
                        lastDeviationAlert = now
                        alert("Route deviation detected", "Your location is approximately ${formatDistance(offRoute)} from the planned route.", 3)
                    }
                }
            }
        }
        try { fused.requestLocationUpdates(request, callback!!, mainLooper) } catch (_: SecurityException) { stopSelf() }
    }

    // Approximate perpendicular distance to each route segment in a local metric projection.
    private fun distanceToRoute(lat: Double, lon: Double, points: List<Pair<Double, Double>>): Double {
        if (points.isEmpty()) return Double.MAX_VALUE
        if (points.size == 1) return distanceMeters(lat, lon, points[0].first, points[0].second)
        val earth = 6371000.0
        val cosLat = cos(Math.toRadians(lat)).coerceAtLeast(0.000001)
        fun xy(p: Pair<Double, Double>): Pair<Double, Double> {
            val x = Math.toRadians(p.second - lon) * earth * cosLat
            val y = Math.toRadians(p.first - lat) * earth
            return Pair(x, y)
        }
        var best = Double.MAX_VALUE
        for (i in 0 until points.size - 1) {
            val a = xy(points[i]); val b = xy(points[i + 1])
            val dx = b.first - a.first; val dy = b.second - a.second
            val denom = dx * dx + dy * dy
            val t = if (denom == 0.0) 0.0 else ((-a.first * dx - a.second * dy) / denom).coerceIn(0.0, 1.0)
            val px = a.first + t * dx; val py = a.second + t * dy
            best = minOf(best, sqrt(px * px + py * py))
        }
        return best
    }

    private fun distanceMeters(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
        val r = 6371000.0; val dLat = Math.toRadians(bLat - aLat); val dLon = Math.toRadians(bLon - aLon)
        val x = sin(dLat / 2).pow(2.0) + cos(Math.toRadians(aLat)) * cos(Math.toRadians(bLat)) * sin(dLon / 2).pow(2.0)
        return 2 * r * asin(sqrt(x.coerceIn(0.0, 1.0)))
    }
    private fun formatDistance(m: Double) = if (m >= 1000) String.format("%.1f km", m / 1000) else "${m.toInt()} m"

    private fun alert(title: String, message: String, id: Int) {
        stopAlert()
        val acknowledgeIntent = Intent(this, TravelMonitorService::class.java).apply { action = ACTION_ACKNOWLEDGE }
        val acknowledgePending = PendingIntent.getService(
            this, 90 + id, acknowledgeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(id, NotificationCompat.Builder(this, "travel_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "I'M AWAKE", acknowledgePending)
            .build())

        try {
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            activeRingtone = RingtoneManager.getRingtone(this, alarmUri)
            if (Build.VERSION.SDK_INT >= 28) activeRingtone?.isLooping = true
            activeRingtone?.play()
        } catch (_: Exception) { }

        try {
            activeVibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            val pattern = longArrayOf(0, 700, 300, 700, 700)
            if (Build.VERSION.SDK_INT >= 26) {
                activeVibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                activeVibrator?.vibrate(pattern, 0)
            }
        } catch (_: Exception) { }
    }

    private fun stopAlert() {
        try { activeRingtone?.stop() } catch (_: Exception) { }
        activeRingtone = null
        try { activeVibrator?.cancel() } catch (_: Exception) { }
        activeVibrator = null
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(2)
        nm.cancel(3)
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, "travel_monitor")
        .setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("TravelGuard is active")
        .setContentText(text).setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build()

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel("travel_monitor", "Journey monitoring", NotificationManager.IMPORTANCE_LOW))
            val alerts = NotificationChannel("travel_alerts", "Travel alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 700, 300, 700, 300, 1000)
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                description = "Destination proximity and route deviation alerts"
            }
            manager.createNotificationChannel(alerts)
        }
    }

    override fun onDestroy() {
        stopAlert()
        callback?.let { fused.removeLocationUpdates(it) }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
