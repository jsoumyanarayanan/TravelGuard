package com.travelguard.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var destination: EditText
    private lateinit var radiusValue: TextView
    private lateinit var deviationValue: TextView
    private lateinit var status: TextView
    private lateinit var map: WebView
    private lateinit var startButton: TextView
    private var radiusMeters = 2000
    private var deviationMeters = 250
    private var destinationLat: Double? = null
    private var destinationLon: Double? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val requestCode = 401

    private val ink = Color.rgb(24, 37, 65)
    private val muted = Color.rgb(103, 116, 139)
    private val blue = Color.rgb(26, 115, 232)
    private val page = Color.rgb(246, 248, 252)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        if (Build.VERSION.SDK_INT >= 26) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        buildUi()
        requestPermissionsIfNeeded()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(page); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(30))
        }
        scroll.addView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mark = TextView(this).apply {
            text = "⌖"; textSize = 28f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); background = rounded(blue, 18); 
        }
        top.addView(mark, Linear(52, 52))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brand.addView(text("TravelGuard", 23f, ink, true))
        brand.addView(text("YOUR JOURNEY, WATCHED OVER", 10f, muted, true))
        top.addView(brand, Linear(0, -2, 1f))
        val live = TextView(this).apply {
            text = "● READY"; textSize = 10f; setTextColor(Color.rgb(20, 137, 91))
            background = rounded(Color.rgb(225, 246, 237), 30); setPadding(dp(11), dp(8), dp(11), dp(8))
        }
        top.addView(live)
        root.addView(top)
        addSpace(root, 20)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(20, 39, 76), 24)
            setPadding(dp(20), dp(20), dp(20), dp(18))
        }
        hero.addView(text("Travel without the worry.", 21f, Color.WHITE, true))
        hero.addView(text("Set your stop. We’ll watch the distance while you rest.", 13f, Color.rgb(207, 219, 239), false).apply {
            setPadding(0, dp(7), 0, dp(16))
        })
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chips.addView(chip("◉  GPS proximity"))
        val gap = View(this); chips.addView(gap, Linear(8, 1))
        chips.addView(chip("↗  Route deviation"))
        hero.addView(chips)
        root.addView(hero)
        addSpace(root, 18)

        root.addView(sectionTitle("01", "WAKE ME UP", "Destination alert"))
        val destinationCard = card()
        destination = EditText(this).apply {
            hint = "Search a station, town or landmark"
            textSize = 15f; singleLine = true; setTextColor(ink); setHintTextColor(Color.rgb(145, 155, 173))
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(Color.rgb(246, 248, 252), 14)
        }
        destinationCard.addView(destination, Linear(-1, 54))
        val search = button("FIND DESTINATION", blue)
        destinationCard.addView(search, Linear(-1, 48).apply { topMargin = dp(10) })
        search.setOnClickListener { resolveDestination(false) }
        addSpace(destinationCard, 17)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("Alert radius", 14f, ink, true), Linear(0, -2, 1f))
        radiusValue = text("2.0 km", 15f, blue, true)
        row.addView(radiusValue)
        destinationCard.addView(row)
        val radiusSlider = SeekBar(this).apply {
            max = 99; progress = 19; progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue)
        }
        destinationCard.addView(radiusSlider, Linear(-1, 38))
        val bounds = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bounds.addView(text("100 m", 11f, muted, false), Linear(0, -2, 1f))
        bounds.addView(text("10 km max", 11f, muted, false))
        destinationCard.addView(bounds)
        radiusSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                radiusMeters = 100 + progress * 100
                radiusValue.text = if (radiusMeters >= 1000) String.format(Locale.US, "%.1f km", radiusMeters / 1000.0) else "$radiusMeters m"
                updateMapCircle()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(destinationCard)
        addSpace(root, 18)

        root.addView(sectionTitle("02", "LIVE MAP", "Your destination radar"))
        val mapCard = card()
        map = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            setBackgroundColor(Color.rgb(230, 237, 246))
        }
        mapCard.addView(map, Linear(-1, 250))
        map.loadDataWithBaseURL("https://localhost/", mapHtml(), "text/html", "UTF-8", null)
        val mapHint = text("Move the radius slider to resize the radar zone.", 12f, muted, false)
        mapHint.setPadding(dp(2), dp(11), dp(2), 0)
        mapCard.addView(mapHint)
        root.addView(mapCard)
        addSpace(root, 18)

        root.addView(sectionTitle("03", "ROUTE GUARD", "Unexpected diversion alert"))
        val routeCard = card()
        routeCard.addView(text("Alert when your GPS position moves away from the planned route.", 13f, muted, false))
        addSpace(routeCard, 12)
        val drow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        drow.addView(text("Deviation threshold", 14f, ink, true), Linear(0, -2, 1f))
        deviationValue = text("250 m", 15f, blue, true)
        drow.addView(deviationValue)
        routeCard.addView(drow)
        val devSlider = SeekBar(this).apply {
            max = 9; progress = 1
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue)
        }
        routeCard.addView(devSlider, Linear(-1, 38))
        devSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                deviationMeters = 100 + p * 100
                deviationValue.text = "$deviationMeters m"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(routeCard)
        addSpace(root, 20)

        startButton = button("▶   START JOURNEY MONITORING", blue)
        root.addView(startButton, Linear(-1, 58))
        startButton.setOnClickListener {
            if (destinationLat == null) resolveDestination(true) else startMonitoring()
        }
        val stop = TextView(this).apply {
            text = "STOP MONITORING"; gravity = Gravity.CENTER; textSize = 13f
            setTextColor(muted); setPadding(0, dp(16), 0, dp(12))
        }
        stop.setOnClickListener {
            stopService(Intent(this@MainActivity, TravelMonitorService::class.java))
            status.text = "Monitoring stopped."
        }
        root.addView(stop)
        status = text("Ready when you are. Search for your destination to begin.", 12f, muted, false)
        status.gravity = Gravity.CENTER
        status.setPadding(dp(10), dp(10), dp(10), dp(8))
        root.addView(status)
        root.addView(text("GPS accuracy and background behaviour depend on device settings. Route calculation needs internet; proximity monitoring uses GPS.", 11f, muted, false).apply {
            gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), 0)
        })
        setContentView(scroll)
    }

    private fun resolveDestination(startAfter: Boolean) {
        val query = destination.text.toString().trim()
        if (query.isBlank()) { destination.error = "Enter your destination"; return }
        status.text = "Finding destination…"
        executor.execute {
            try {
                @Suppress("DEPRECATION")
                val result = Geocoder(this, Locale.getDefault()).getFromLocationName(query, 1)
                runOnUiThread {
                    if (result.isNullOrEmpty()) {
                        status.text = "Destination not found. Try a more specific place name."
                    } else {
                        destinationLat = result[0].latitude
                        destinationLon = result[0].longitude
                        status.text = "Destination found. Radar is centred on $query."
                        updateMapDestination(query)
                        if (startAfter) startMonitoring()
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { status.text = "Could not find the place. Check internet and try again." }
            }
        }
    }

    private fun startMonitoring() {
        val lat = destinationLat ?: return
        val lon = destinationLon ?: return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Location permission is required. Grant it and tap Start again."
            requestPermissionsIfNeeded()
            return
        }
        val intent = Intent(this, TravelMonitorService::class.java).apply {
            putExtra("dest_name", destination.text.toString().trim())
            putExtra("dest_lat", lat)
            putExtra("dest_lon", lon)
            putExtra("radius_m", radiusMeters.toDouble())
            putExtra("deviation_m", deviationMeters.toDouble())
        }
        try {
            ContextCompat.startForegroundService(this, intent)
            status.text = "Journey monitoring is active. Keep TravelGuard running in the background."
            startButton.text = "✓   MONITORING ACTIVE"
        } catch (_: Exception) {
            status.text = "Could not start monitoring. Check location and notification permissions."
        }
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), requestCode)
    }

    private fun updateMapDestination(name: String) {
        val lat = destinationLat ?: return; val lon = destinationLon ?: return
        map.evaluateJavascript("setDestination($lat,$lon,${radiusMeters},${jsString(name)});", null)
    }
    private fun updateMapCircle() {
        val lat = destinationLat ?: return; val lon = destinationLon ?: return
        map.evaluateJavascript("setRadius($radiusMeters);", null)
    }
    private fun jsString(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ") + "\""

    private fun mapHtml() = """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>html,body,#map{height:100%;width:100%;margin:0;background:#e8eef7}.leaflet-control-attribution{font-size:8px}.pin{width:16px;height:16px;background:#1a73e8;border:4px solid white;border-radius:50%;box-shadow:0 2px 8px #3455}</style>
</head><body><div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>
const map=L.map('map',{zoomControl:false}).setView([20.59,78.96],4);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
L.control.zoom({position:'bottomright'}).addTo(map);
let marker=null,ring=null;
function setDestination(lat,lon,r,name){
 if(marker)map.removeLayer(marker); if(ring)map.removeLayer(ring);
 marker=L.marker([lat,lon]).addTo(map).bindPopup(name);
 ring=L.circle([lat,lon],{radius:r,color:'#1a73e8',weight:2,fillColor:'#4285f4',fillOpacity:.15}).addTo(map);
 map.flyTo([lat,lon],Math.max(10,map.getZoom()),{duration:1.0});
}
function setRadius(r){if(ring){ring.setRadius(r);ring.setStyle({fillOpacity:.12+Math.min(r/10000,.15)});}}
</script></body></html>
    """.trimIndent()

    private fun sectionTitle(number: String, title: String, subtitle: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val num = TextView(this).apply {
            text = number; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(blue); background = rounded(Color.rgb(229, 239, 255), 10)
        }
        row.addView(num, Linear(34, 34))
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, 0, 0) }
        labels.addView(text(title, 12f, blue, true))
        labels.addView(text(subtitle, 17f, ink, true))
        row.addView(labels)
        return row
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(Color.WHITE, 20)
        elevation = dp(2).toFloat()
    }
    private fun chip(label: String) = TextView(this).apply {
        text = label; textSize = 10f; setTextColor(Color.WHITE)
        background = rounded(0x334F7FCB, 30); setPadding(dp(10), dp(8), dp(10), dp(8))
    }
    private fun button(label: String, color: Int) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE); background = rounded(color, 16)
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun Linear(width: Int, height: Int, weight: Float = 0f) =
        LinearLayout.LayoutParams(if (width < 0) width else dp(width), if (height < 0) height else dp(height), weight)
    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), Linear(height, 1))
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdown()
        map.destroy()
        super.onDestroy()
    }
}
