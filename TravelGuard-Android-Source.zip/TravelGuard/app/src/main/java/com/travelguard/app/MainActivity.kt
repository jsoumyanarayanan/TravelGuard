package com.travelguard.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var destination: EditText
    private lateinit var radius: Spinner
    private lateinit var deviation: Spinner
    private lateinit var status: TextView
    private val requestCode = 401

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestPermissionsIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(0xFFF4F6FB.toInt())
        }
        val title = TextView(this).apply {
            text = "TravelGuard"
            textSize = 30f
            setTextColor(0xFF14264A.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "Sleep peacefully. Travel with confidence."
            textSize = 14f
            setTextColor(0xFF53627A.toInt())
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(section("WAKE ME UP · Destination alert"))
        destination = EditText(this).apply {
            hint = "Destination (e.g. Madurai Railway Station)"
            textSize = 16f
            setSingleLine(true)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(destination, LinearLayout.LayoutParams(-1, 58).apply { topMargin = 12 })
        root.addView(label("Alert before destination"))
        radius = spinner(listOf("10 km", "5 km", "2 km", "1 km", "500 m"))
        root.addView(radius)

        root.addView(section("ROUTE GUARD · Deviation alert"))
        root.addView(label("Warn when you move this far from the planned route"))
        deviation = spinner(listOf("100 m", "250 m", "500 m", "1 km"))
        deviation.setSelection(1)
        root.addView(deviation)

        val start = Button(this).apply {
            text = "START JOURNEY MONITORING"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF2457D6.toInt())
            setOnClickListener { startMonitoring() }
        }
        root.addView(start, LinearLayout.LayoutParams(-1, 58).apply { topMargin = 24 })
        val stop = Button(this).apply {
            text = "STOP MONITORING"
            setOnClickListener { stopService(Intent(this@MainActivity, TravelMonitorService::class.java)); status.text = "Monitoring stopped." }
        }
        root.addView(stop, LinearLayout.LayoutParams(-1, 50).apply { topMargin = 8 })
        status = TextView(this).apply {
            text = "Set a destination and start monitoring. Keep location enabled."
            textSize = 13f
            setTextColor(0xFF53627A.toInt())
            setPadding(0, 18, 0, 0)
        }
        root.addView(status)
        val note = TextView(this).apply {
            text = "Note: Route Guard compares your GPS position with a route calculated when monitoring starts. Diversions may trigger an alert. Internet is needed to calculate the route."
            textSize = 12f
            setTextColor(0xFF6C778A.toInt())
            setPadding(0, 18, 0, 0)
        }
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xFF2457D6.toInt())
        setPadding(0, 26, 0, 4)
    }
    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xFF263650.toInt())
        setPadding(0, 14, 0, 6)
    }
    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), requestCode)
    }

    private fun startMonitoring() {
        val query = destination.text.toString().trim()
        if (query.isBlank()) { destination.error = "Enter your destination"; return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Location permission is required. Grant it and try again."
            requestPermissionsIfNeeded()
            return
        }
        try {
            @Suppress("DEPRECATION")
            val result = Geocoder(this, Locale.getDefault()).getFromLocationName(query, 1)
            if (result.isNullOrEmpty()) { status.text = "Destination not found. Try a more specific place name."; return }
            val place = result[0]
            val r = radius.selectedItem.toString().let { if (it.endsWith("km")) it.removeSuffix(" km").toDouble() * 1000 else it.removeSuffix(" m").toDouble() }
            val d = deviation.selectedItem.toString().let { if (it.endsWith("km")) it.removeSuffix(" km").toDouble() * 1000 else it.removeSuffix(" m").toDouble() }
            val intent = Intent(this, TravelMonitorService::class.java).apply {
                putExtra("dest_name", query)
                putExtra("dest_lat", place.latitude)
                putExtra("dest_lon", place.longitude)
                putExtra("radius_m", r)
                putExtra("deviation_m", d)
            }
            ContextCompat.startForegroundService(this, intent)
            status.text = "Monitoring started for $query. Keep this app's location permission enabled."
        } catch (e: Exception) {
            status.text = "Could not find destination. Check internet/location services and try again."
        }
    }
}
