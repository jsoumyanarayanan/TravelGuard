# TravelGuard (Android MVP source project)

A small native Android prototype with two features:

- **Wake Me Up:** geocodes a typed destination and triggers a proximity notification with vibration and alarm-channel sound when the phone enters the selected radius.
- **Route Guard:** requests a driving route from the phone's starting GPS location to the destination using the public OSRM demo routing service, then warns after three consecutive GPS fixes remain beyond the selected distance from that route.

## Open and build

1. Install Android Studio (current stable) on a computer.
2. Extract this folder and open `TravelGuard` in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin, Kotlin plugin and Google Play Services Location dependency.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the generated debug APK on your phone.

## First-run setup

- Enable Location and grant precise location.
- Grant notification permission.
- For best locked-screen reliability, set app location permission to **Allow all the time** in Android Settings and disable battery optimization for TravelGuard if your phone manufacturer restricts background services.
- Ensure the Travel alerts notification channel is allowed to make sound and vibrate. Android silent/DND settings may suppress sound; this app does not bypass them.
- Start monitoring while the app is visible. Android requires a persistent foreground-service notification during active tracking.

## Important MVP limitations

- This is source code, not a prebuilt APK. It has not been compiled or tested on a physical device in this environment.
- Destination lookup uses Android Geocoder; results depend on device geocoding availability.
- Route Guard uses the public OSRM demo server. It is a prototype endpoint, not a guaranteed production service. The route is calculated once at journey start; legitimate diversions can trigger an alert. Restart monitoring to establish a new route.
- The current deviation calculation checks distance to sampled route points, so a production version should calculate distance to route segments and add map matching, rerouting, GPS accuracy checks and stronger false-positive handling.
- Destination proximity is based on the phone's GPS position, not the bus's actual position. Tunnels, poor GPS reception and battery restrictions can delay alerts.
- Android notification channel settings are controlled by the user and may need adjustment. The app cannot reliably override silent mode or Do Not Disturb.
- OSRM receives the route endpoint coordinates. Review its service policy before using it for real journeys; replace it with a production routing provider before public release.

## Suggested next production upgrades

1. Map screen with destination pin and route preview.
2. Route-segment distance calculation and GPS accuracy filtering.
3. Separate alert distances with independent enable/disable controls.
4. Persistent journey recovery after reboot and explicit stop/acknowledge controls.
5. Production routing provider and privacy disclosure.
6. Tested Android 13–16 permission flow and battery behavior across Samsung, Xiaomi, OnePlus and Pixel devices.
